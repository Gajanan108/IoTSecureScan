# Bluetooth - characteristic
## Goal
* One time password bluetooth device
* Works with an android application, but you don't have it
* The goal is to provide a screenshot of the password

## Tips
Verbose mode = 1 on 0000ffe1

## Result
The password is an animal name.
