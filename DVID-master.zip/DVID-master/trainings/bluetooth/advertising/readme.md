# Bluetooth - advertising
## Goal
* A confidential message is stored on the firmware but protected by a password
* The goal is to provide a screenshot of the confidential message

## Tips
Hey ! Advertise me to know my name

## Result
The password is an animal name.
