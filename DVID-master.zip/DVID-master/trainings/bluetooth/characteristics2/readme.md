# Bluetooth - characteristic2
## Goal
* A confidential message is stored on the firmware but protected by a password
* The goal is to provide a screenshot of the confidential message

## Tips
Come on to say hello on 0000ffe1

## Result
The password is an animal name.
