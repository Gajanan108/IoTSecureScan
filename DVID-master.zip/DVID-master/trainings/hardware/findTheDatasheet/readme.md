# Find the datasheet training
## Goal
A password is displayed on the pin PD1

## Guidelines
The DVID board contains a microcontroller
* Find the datasheet on Internet to identify the PD1
* Find PD1 pin correspondance on DVID (ex.: github)
* Connect a UART RX to PD1 to get the password

## Result
The password is a l33t string
