var searchData=
[
  ['bgncol',['bgnCol',['../struct_ticker_state.html#ac9acf7f7afbfff4dd845e152dfa88e4d',1,'TickerState']]]
];
