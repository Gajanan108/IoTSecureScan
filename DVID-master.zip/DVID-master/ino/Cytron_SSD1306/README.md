# Lightweight-I2C-SSD1306

Lightweight I2C SSD1306 Arduino Library for displaying text and simple bitmap images.</br>

<b>Dependencies:</b>
<ul>
<li><a href="https://github.com/greiman/SSD1306Ascii" target=_blank><b>SSD1306Ascii</b> by Greiman</a></li>
</ul>
